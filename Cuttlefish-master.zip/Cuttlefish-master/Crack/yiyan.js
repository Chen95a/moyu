/*
Unlocks by Cuttlefish 公众号：墨鱼手记
*/
var body = $response.body.replace(/viptype":"1"/g, 'viptype":"4"')
$done({ body });
