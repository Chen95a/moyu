/*
Unlocks by Cuttlefish 公众号：墨鱼手记
*/
var body = $response.body.replace(/\u0069\u0073\u0066\u0072\u0065\u0065\u0022\u003a\u0030/g, '\u0069\u0073\u0066\u0072\u0065\u0065\u0022\u003a\u0031');
$done({ body });
