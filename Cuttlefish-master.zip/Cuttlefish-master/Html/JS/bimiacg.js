document.getElementById("kadDCtnM_cs").style.display="none";
document.getElementById("afc_sidebar_2842").style.display="none";
