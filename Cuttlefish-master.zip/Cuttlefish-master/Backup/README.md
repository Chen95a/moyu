**Awesome Github**
* Update Time: 2022-04-05
* 备份一些Github库源

| 名称 | 网址 | 备注 |
| :-- | :-- | :-: |
| 墨鱼手记 | https://github.com/ddgksf2013/Cuttlefish |  |
| 油管下载 | https://github.com/database64128/youtube-dl-wpf |  |
| 音乐下载 | https://github.com/Java-S12138/Music_Dowload |  |
| 网易云音乐下载 | https://github.com/CcphAmy/NetEaseCloudMusic-nonmembership-list-download |  |
| 微信聊天记录导出  | https://github.com/BlueMatthew/WechatExporter |  |
| 蓝奏云GUI | https://github.com/rachpt/lanzou-gui |  |
| ClashN | https://github.com/2dust/clashN/ |  |
| 动画疯自动下载 | https://github.com/miyouzi/aniGamerPlus |  |
| 文章同步助手 | https://github.com/wechatsync/Wechatsync |  |
| 人人影视bot | https://github.com/tgbot-collection/YYeTsBot |  |
| 面试刷题 | https://github.com/liyupi/mianshiya-public | | 
| 微信读书助手 | https://github.com/arry-lee/wereader | | 
| B站工具合集 | https://github.com/HCLonely/awesome-bilibili-extra | |
| 字幕机翻助手 | https://github.com/1c7/Translate-Subtitle-File | |
| 万能win&office激活 | https://github.com/zbezj/HEU_KMS_Activator | |
| 直播源 | https://github.com/iptv-org/iptv | |
| 阿里云盘小白羊 | https://github.com/liupan1890/aliyunpan | |
| Apple相关服务解锁 | https://github.com/VirgilClyne/iRingo/tree/main#quantumult-x |
| 投稿助手 | https://t.me/ddgksf2013_bot |  |


